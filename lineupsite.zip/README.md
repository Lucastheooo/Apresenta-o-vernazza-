# LineUp — site

Aceleradora comercial. **O fim do vazamento de receita.**

Site institucional de página única, estático (HTML/CSS/JS), sem build e sem
dependências externas em runtime. Monocromático, mobile-first, com foco em
performance e acessibilidade.

---

## 1. Estrutura

```
.
├── index.html              # a página inteira (CSS e JS inline)
├── 404.html                # página de erro on-brand
├── og.png                  # imagem de compartilhamento 1200×630
├── favicon.svg             # marca (a linha que sobe)
├── favicon-32.png          # fallback de favicon
├── apple-touch-icon.png    # ícone iOS 180×180
├── fonts/
│   ├── archivo.woff2        # Archivo variável (100–900), subset latin
│   └── ibmplexmono-500.woff2
├── _headers                # cache + segurança (Cloudflare Pages / Netlify)
├── robots.txt
├── sitemap.xml
└── README.md
```

As fontes são **self-hosted** (não há requisição ao Google Fonts): mais rápido,
mais privado e funciona offline.

---

## 2. Rodar localmente

Qualquer servidor estático serve. Exemplos:

```bash
# Python
python3 -m http.server 8000

# Node
npx serve .
```

Abra <http://localhost:8000>. Não basta abrir o `index.html` com `file://`
porque o navegador bloqueia o carregamento das fontes self-hosted.

---

## 3. Deploy (estático, HTTPS automático)

`index.html` é a raiz — não há etapa de build. Escolha **um** host.

### Opção A — Cloudflare Pages

**Arrastar a pasta (mais rápido):**
1. Acesse <https://dash.cloudflare.com> → **Workers & Pages** → **Create** → **Pages** → **Upload assets**.
2. Arraste a pasta inteira do projeto.
3. **Deploy**. Sai no ar em `https://<seu-projeto>.pages.dev` com HTTPS.

**Conectar o repositório (deploy a cada push):**
1. **Pages** → **Connect to Git** → escolha este repositório.
2. **Build command:** deixe vazio. **Build output directory:** `/` (raiz).
3. **Save and Deploy**.

### Opção B — Netlify

**Arrastar a pasta:**
1. Acesse <https://app.netlify.com/drop>.
2. Arraste a pasta do projeto. Pronto: `https://<nome>.netlify.app` com HTTPS.

**Conectar o repositório:**
1. **Add new site** → **Import an existing project** → conecte o Git.
2. **Build command:** vazio. **Publish directory:** `.` (raiz).
3. **Deploy**.

> O arquivo `_headers` é lido automaticamente pelos dois hosts (cache longo
> para fontes/ícones, headers de segurança). Nada a configurar.

---

## 4. Domínio próprio (ex.: lineup.com.br)

Depois do site no ar no subdomínio do host:

**Cloudflare Pages:** projeto → **Custom domains** → **Set up a domain** →
digite `lineup.com.br`. Se o domínio já estiver na Cloudflare, o DNS é
configurado sozinho. Se estiver em outro registrador, aponte conforme as
instruções (CNAME para `pages.dev` no `www` e registro do apex).

**Netlify:** **Domain settings** → **Add a custom domain** → `lineup.com.br`.
Use os nameservers da Netlify **ou** crie um `CNAME` de `www` para o site e um
`ALIAS/ANAME`/registro de apex apontando para a Netlify.

**HTTPS:** certificado Let's Encrypt é emitido automaticamente nos dois hosts
após o DNS propagar (alguns minutos). Não precisa fazer nada.

**Após apontar o domínio**, troque a URL nestes lugares (estão todos com
`https://lineup.com.br`):
- `index.html`: `<link rel="canonical">`, `og:url`, `og:image`, `twitter:image`,
  e o bloco JSON-LD.
- `robots.txt` e `sitemap.xml`.

Se o domínio final **não** for `lineup.com.br`, é só um find/replace por
`lineup.com.br`.

---

## 5. ⚠️ Placeholders — o que falta preencher

Tudo abaixo está marcado no código com `[ colchetes ]`. Procure por estes
trechos:

| Item | Onde | O que fazer |
|------|------|-------------|
| **Nome do fundador** | `index.html` → seção `#fundador`, `[Seu nome]` | Trocar pelo nome real. |
| **Foto do fundador** | `index.html` → `.founder__photo` | Adicionar `founder.jpg` na pasta e descomentar a tag `<img>` (já está pronta, comentada). Retrato vertical ~4:5. |
| **Autoridade do fundador** | `index.html` → `[Resumo de autoridade…]` | 1–2 frases concretas: o que já operou, em que escala, com qual resultado. |
| **LinkedIn** | `index.html` → `.linkedin` (`href="#"`) | Trocar `#` pela URL real do perfil. |
| **E-mail** | `index.html` (rodapé) | `contato@lineup.com.br` é placeholder — troque pelo e-mail real. |
| **Cidade** | `index.html` (rodapé) | “São Paulo · Brasil” é placeholder. |
| **Domínio** | ver seção 4 | Trocar `lineup.com.br` quando o domínio final estiver definido. |
| **Agenda (opcional)** | — | Se quiser usar Cal.com/Calendly em vez do qualificador, mande o link. |
| **Métricas reais (opcional)** | `index.html` → dashboard/funil | Se quiser números reais no lugar dos exemplos, troque e remova as etiquetas “Exemplo”. |

**Já está correto e não precisa mexer:** o número de WhatsApp
`+55 98 98787-0947` (`5598987870947`).

---

## 6. Funil de entrada (qualificador)

O CTA principal **não** abre o WhatsApp cru. Ele roda um qualificador de 4
perguntas (segmento, faturamento, gargalo, ticket) e, no fim, **monta uma
mensagem estruturada** e abre o WhatsApp já preenchido
(`https://wa.me/5598987870947?text=...`). Nada é enviado automaticamente — o
usuário revisa e manda. O WhatsApp cru fica só como **canal secundário** no
rodapé.

Quer trocar por **agenda embarcada** (Cal.com/Calendly) ou por um **agente de
IA de verdade** na home? Os dois são suportados pela estrutura — mande o link
da agenda ou a API/endpoint do agente que eu ligo.

---

## 7. Regenerar imagens (opcional)

`og.png`, `favicon-32.png` e `apple-touch-icon.png` foram gerados com Pillow
usando as fontes da marca. Para refazer (ex.: novo texto na OG), use Pillow
(`pip install Pillow`). O `favicon.svg` é vetorial e pode ser editado direto.

---

## 8. Honestidade dos números

Todos os painéis, percentuais do funil e métricas do site são **exemplos
ilustrativos** e estão marcados como tal (“Exemplo”). Não há dados de clientes
reais nem cases forjados. Ao usar números reais do operador, substitua os
exemplos e remova as etiquetas “Exemplo” correspondentes.
